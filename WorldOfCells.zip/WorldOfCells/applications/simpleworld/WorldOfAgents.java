/*import java.util.ArrayList;

public class WorldOfAgents extends World{
	private ArrayList<Human> humans;
	private ArrayList<Zombie> zombies;
	private ArrayList<Animal> animals;
	protected AgentsCA cellularAutomata;
	
	public WorldOfAgents(){
		humans=new ArrayList<Human>();
		zombies=new ArrayList<Zombie>()	;
		animals=new ArrayList<Animal>()	;
	}
	
	/*protected void stepAgents(){
		
	}
}*/
